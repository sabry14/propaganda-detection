
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Header from './components/Header';
import PropagandaForm from './components/PropagandaForm';
import AboutUs from './components/AboutUs';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Header />} />
      </Routes>
      <PropagandaForm />
      <AboutUs />
      <Footer />
    </Router>
  );
}

export default App;
