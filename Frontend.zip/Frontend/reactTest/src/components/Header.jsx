import '../App.css';

function Header() {
  return (
    <header className="masthead">
      <div className="container position-relative">
        <div className="row justify-content-center">
          <div className="col-xl-8">
            <div className="text-center text-white">
              <h1 className="badge text-bg-primary text-wrap mb-5">
                Spot the Spin: Analyze Your Text for Hidden Propaganda
              </h1>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
