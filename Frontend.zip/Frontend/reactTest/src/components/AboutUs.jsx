import '../App.css';

function AboutUs() {
  return (
    <section id="about-us" className="testimonials text-center bg-light" style={{ backgroundColor: '#0D6EFD' }}>
      <div className="container">
        <h2 className="mb-5" style={{ color: '#fff' }}>Who We Are ...</h2>
        <div className="row">
          <div className="col-lg-4">
            <div className="testimonial-item mx-auto mb-5 mb-lg-0">
              <img className="img-fluid rounded-circle mb-3" src="src/assets/img/1662594601260.jpg" alt="Mohamed Sabry" />
              <h5 style={{ color: '#fff' }}>Mohamed Sabry</h5>
              <p className="font-weight-light mb-0" style={{ color: '#fff' }}>A passionate AI enthusiast dedicated to leveraging technology for impactful solutions.</p>
            </div>
          </div>
          <div className="col-lg-4">
            <div className="testimonial-item mx-auto mb-5 mb-lg-0">
              <img className="img-fluid rounded-circle mb-3" src="src/assets/img/mahdi.jpg" alt="Ahmed Mahdi" />
              <h5 style={{ color: '#fff' }}>Ahmed Mahdi</h5>
              <p className="font-weight-light mb-0" style={{ color: '#fff' }}>A skilled Data Scientist with expertise in machine learning and a keen interest in data-driven insights.</p>
            </div>
          </div>
          <div className="col-lg-4">
            <div className="testimonial-item mx-auto mb-5 mb-lg-0">
              <img className="img-fluid rounded-circle mb-3" src="src/assets/img/1678909156995.jpg" alt="Abdallah Abdelmalik" />
              <h5 style={{ color: '#fff' }}>Abdallah Abdelmalik</h5>
              <p className="font-weight-light mb-0" style={{ color: '#fff' }}>A talented Developer focused on building innovative applications that enhance user experience.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}


export default AboutUs;
