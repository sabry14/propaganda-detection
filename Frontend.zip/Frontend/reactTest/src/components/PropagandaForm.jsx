import { useState } from 'react';

function PropagandaForm() {
    const [inputText, setInputText] = useState('');  // State to store input text
    const [result, setResult] = useState('');        // State to store result from backend

    // Function to handle form submission
    const handleSubmit = async () => {
        try {
            // Making a POST request to the Flask backend
            const response = await fetch('http://127.0.0.1:5000/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ text: inputText }),  // Send input text to backend in JSON format
            });

            // Parse the JSON response from the backend
            const data = await response.json();
            
            // Check if the backend predicted class for propaganda (1) or no propaganda (0)
            if (data.predicted_class === 1) {
                setResult('Propaganda Detected');
            } else if (data.predicted_class === 0) {
                setResult('No Propaganda');
            } else {
                setResult('Unknown response from server');
            }
        } catch (error) {
            console.error('Error:', error);
            setResult('Error analyzing the text');
        }
    };

    return (
        <section className="features-icons bg-light text-center" style={{ height: '500px' }}>
            <div className="container">
                <div className="form-floating mb-1 col-6 mx-auto">
                    {/* Textarea to input the sentence */}
                    <textarea
                        className="form-control"
                        id="floatingInput"
                        placeholder="Enter text"
                        style={{ height: '150px' }}
                        value={inputText}  // Input text state binding
                        onChange={(e) => setInputText(e.target.value)}  // Update state on input change
                    />
                    <label htmlFor="floatingInput" >Propaganda Sentence</label>
                </div>
                
                {/* Button to trigger analyze */}
                <div className="col-md-4 col-6 mx-auto mt-4">
                    <button className="btn btn-outline-primary" onClick={handleSubmit} type="button">
                        Analyze
                    </button>
                </div>

                {/* Display result from backend */}
                <div className="alert bg-primary text-light col-6 mx-auto mt-4" role="alert">
                    <h3>{result}</h3>
                </div>
            </div>
        </section>
    );
}

export default PropagandaForm;
