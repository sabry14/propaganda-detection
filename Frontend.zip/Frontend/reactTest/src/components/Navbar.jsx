import '../App.css';

import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav className="navbar navbar-light bg-light static-top">
      <div className="container">
        <Link className="navbar-brand" to="/">Propaganda Detector</Link>
        <a className="btn btn-primary" href="#about-us">About Us</a>
      </div>
    </nav>
  );
}

export default Navbar;
